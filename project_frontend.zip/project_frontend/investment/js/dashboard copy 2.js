const hide_link= document.querySelectorAll('.swsz')
const hide_icon= document.querySelectorAll('.bi-chevron-down')
const top_bar = document.querySelector('.bi-text-paragraph')
const main_con = document.querySelector('.xmain-consa')
const x_bar = document.querySelector('.bi-x')
const xsd21 = document.querySelectorAll('.xsd21')
const con_hover = document.querySelector('.main-one-con')
const main_all_con = document.querySelector(' .xmain-consa')
const main_all_con2 = document.querySelectorAll('.main-lef')
const hiddenc = document.querySelectorAll('.hiddenc')
const mediax_body = document.querySelector('.xbody')
const mediax_conhide = document.querySelector('.dsdf')
const main_lef = document.querySelector('.main-lef')
const show12 = document.querySelectorAll('.hiddenc')
let ks = true





const chevron = document.querySelectorAll('.bi-chevron-down')


// document.c


let ticks = 0


  

const anin = document.querySelector('.anin')

function loads() {
    anin.classList.add('aninhide')
    document.style.transition = 'all 3s  cubic-bezier(0.165, 0.84, 0.44, 1)'
    
}
setTimeout(() => {
    document.addEventListener('load',loads() )
    
}, 2000);
